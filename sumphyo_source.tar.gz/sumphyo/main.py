from kivy.app import App
from kivy.uix.screenmanager import ScreenManager

from services.auth_service import AuthService
from services.data_service import DataService
from services.matching_service import MatchingService

from ui.screens.login_screen import LoginScreen
from ui.screens.register_screen import RegisterScreen
from ui.screens.main_screen import MainScreen

class FreeTimeMatcherApp(App):
    def build(self):
        # 서비스 초기화
        self.auth_service = AuthService()
        self.data_service = DataService()
        self.matching_service = MatchingService()
        
        # 한글 폰트 설정
        self._setup_fonts()
        
        # 화면 관리자 설정
        sm = ScreenManager()
        sm.add_widget(LoginScreen(self.auth_service, name='login'))
        sm.add_widget(RegisterScreen(self.auth_service, name='register'))
        sm.add_widget(MainScreen(self.auth_service, self.data_service, self.matching_service, name='main'))
        
        return sm
    
    def _setup_fonts(self):
        from kivy.core.text import LabelBase
        from kivy.resources import resource_add_path
        
        resource_add_path('assets')  # 폰트 파일 경로
        resource_add_path('/System/Library/Fonts')  # macOS 시스템 폰트
        
        try:
            LabelBase.register('Roboto', 'AppleGothic.ttf')
        except:
            try:
                LabelBase.register('Roboto', 'AppleSDGothicNeo.ttc')
            except:
                print("Warning: 한글 폰트를 찾을 수 없습니다.")

if __name__ == "__main__":
    FreeTimeMatcherApp().run()