kivy기반

실행방법 : dist - sumphyo - sumphyo

python 3.7이상 사용 권고

가상환경 생성 및 활성 필요

구조

sumphyo/
├── main.py                  # 메인 실행 파일
├── config.py                # 앱 전역 설정 및 상수
├── assets/                  # 이미지, 폰트 등 리소스
│   └── default_profile.png  # 기본 프로필 이미지
├── data/                    # 데이터 저장 디렉토리
│   ├── users.json           # 사용자 정보
│   └── schedules.json       # 시간표 정보
├── models/                  # 데이터 모델
│   ├── __init__.py
│   ├── user.py              # 사용자 모델
│   └── schedule.py          # 시간표 모델
├── services/                # 서비스 로직
│   ├── __init__.py
│   ├── auth_service.py      # 인증 서비스
│   ├── data_service.py      # 데이터 처리 서비스
│   └── matching_service.py  # 매칭 알고리즘 서비스
└── ui/                      # UI 컴포넌트
    ├── __init__.py
    ├── styles.py            # UI 스타일 정의
    ├── screens/             # 화면 클래스
    │   ├── __init__.py
    │   ├── login_screen.py  # 로그인 화면
    │   ├── register_screen.py # 회원가입 화면
    │   └── main_screen.py   # 메인 화면 (탭 포함)
    └── widgets/             # 재사용 위젯
        ├── __init__.py
        └── profile_card.py  # 프로필 카드 위젯