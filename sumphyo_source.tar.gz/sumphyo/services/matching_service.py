from services.data_service import DataService
import config

class MatchingService:
    def __init__(self):
        self.data_service = DataService()
        
    def find_matches(self, username, min_matching_hours=2):
        """매칭 찾기"""
        user_schedule = self.data_service.get_schedule(username)
        if not user_schedule:
            return []
            
        all_schedules = self.data_service.get_all_schedules()
        matches = []
        
        for schedule in all_schedules:
            if schedule.username == username:
                continue  # 자기 자신 제외
                
            matching_hours = self._calculate_matching_hours(user_schedule, schedule)
            if matching_hours >= min_matching_hours:
                user = self.data_service.get_user(schedule.username)
                if user:
                    matches.append({
                        "user": user,
                        "matching_hours": matching_hours
                    })
                    
        # 매칭 시간 순으로 정렬
        matches.sort(key=lambda x: x["matching_hours"], reverse=True)
        return matches
        
    def _calculate_matching_hours(self, schedule1, schedule2):
        """두 시간표 간의 공통 공강 시간 계산"""
        total_matching_hours = 0
        
        for day in config.DAYS:
            for time_slot in config.TIME_SLOTS:
                if schedule1.is_free_time(day, time_slot) and schedule2.is_free_time(day, time_slot):
                    total_matching_hours += 1
                    
        return total_matching_hours