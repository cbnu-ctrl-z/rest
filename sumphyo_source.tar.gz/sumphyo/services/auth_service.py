from services.data_service import DataService
from models.user import User

class AuthService:
    def __init__(self):
        self.data_service = DataService()
        self.current_user = None
        
    def login(self, username, password):
        """로그인"""
        user = self.data_service.get_user(username)
        if user and user.password == password:  # 실제로는 해시 비교
            self.current_user = user
            return True
        return False
        
    def logout(self):
        """로그아웃"""
        self.current_user = None
        
    def register(self, username, email, password, **kwargs):
        """회원가입"""
        if self.data_service.get_user(username):
            return False  # 이미 존재하는 사용자
            
        user = User(username, email, password, **kwargs)
        return self.data_service.save_user(user)
        
    def get_current_user(self):
        """현재 로그인한 사용자 정보"""
        return self.current_user
        
    def update_profile(self, **kwargs):
        """프로필 정보 업데이트"""
        if not self.current_user:
            return False
            
        for key, value in kwargs.items():
            if hasattr(self.current_user, key):
                setattr(self.current_user, key, value)
                
        return self.data_service.save_user(self.current_user)