import json
import os
from models.user import User
from models.schedule import Schedule
import config

class DataService:
    def __init__(self, user_file=None, schedule_file=None):
        self.user_file = user_file or config.USER_DATA_FILE
        self.schedule_file = schedule_file or config.SCHEDULE_DATA_FILE
        self._initialize_data_files()
        
    def _initialize_data_files(self):
        """데이터 파일 초기화"""
        os.makedirs(os.path.dirname(self.user_file), exist_ok=True)
        os.makedirs(os.path.dirname(self.schedule_file), exist_ok=True)
        
        if not os.path.exists(self.user_file):
            with open(self.user_file, 'w') as f:
                json.dump([], f)
                
        if not os.path.exists(self.schedule_file):
            with open(self.schedule_file, 'w') as f:
                json.dump([], f)
    
    def save_user(self, user):
        """사용자 정보 저장"""
        users = self._load_users()
        
        # 중복 사용자 확인 및 업데이트
        for i, existing_user in enumerate(users):
            if existing_user.get("username") == user.username:
                users[i] = user.to_dict()
                break
        else:
            # 중복이 없으면 새로 추가
            users.append(user.to_dict())
        
        with open(self.user_file, 'w') as f:
            json.dump(users, f, indent=4)
            
        return True
    
    def get_user(self, username):
        """사용자 정보 조회"""
        users = self._load_users()
        for user_data in users:
            if user_data.get("username") == username:
                return User.from_dict(user_data)
        return None
    
    def _load_users(self):
        """사용자 정보 로드"""
        try:
            with open(self.user_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    def save_schedule(self, schedule):
        """시간표 정보 저장"""
        schedules = self._load_schedules()
        
        # 기존 스케줄 확인 및 업데이트
        for i, existing_schedule in enumerate(schedules):
            if existing_schedule.get("username") == schedule.username:
                schedules[i] = schedule.to_dict()
                break
        else:
            # 중복이 없으면 새로 추가
            schedules.append(schedule.to_dict())
        
        with open(self.schedule_file, 'w') as f:
            json.dump(schedules, f, indent=4)
            
        return True
    
    def get_schedule(self, username):
        """시간표 정보 조회"""
        schedules = self._load_schedules()
        for schedule_data in schedules:
            if schedule_data.get("username") == username:
                return Schedule.from_dict(schedule_data)
        return None
    
    def get_all_schedules(self):
        """모든 시간표 정보 조회"""
        schedules = []
        for schedule_data in self._load_schedules():
            schedules.append(Schedule.from_dict(schedule_data))
        return schedules
    
    def _load_schedules(self):
        """시간표 정보 로드"""
        try:
            with open(self.schedule_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []