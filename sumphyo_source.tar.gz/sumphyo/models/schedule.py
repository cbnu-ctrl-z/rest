class Schedule:
    def __init__(self, username, schedule_data=None):
        self.username = username
        self.schedule_data = schedule_data or {}
        
    def is_free_time(self, day, time_slot):
        """특정 시간이 공강인지 확인"""
        if day in self.schedule_data and time_slot in self.schedule_data[day]:
            return self.schedule_data[day][time_slot]
        return False
        
    def set_free_time(self, day, time_slot, is_free):
        """공강 시간 설정"""
        if day not in self.schedule_data:
            self.schedule_data[day] = {}
        self.schedule_data[day][time_slot] = is_free
        
    def to_dict(self):
        """시간표 정보를 딕셔너리로 변환"""
        return {
            "username": self.username,
            "schedule": self.schedule_data
        }
        
    @classmethod
    def from_dict(cls, data):
        """딕셔너리에서 시간표 객체 생성"""
        return cls(
            username=data.get("username", ""),
            schedule_data=data.get("schedule", {})
        )