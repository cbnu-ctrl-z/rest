class User:
    def __init__(self, username, email, password, department="", interests="", gender="", age="", mbti="", profile_pic=""):
        self.username = username
        self.email = email
        self.password = password  # 실제로는 해시 처리
        self.department = department
        self.interests = interests
        self.gender = gender
        self.age = age
        self.mbti = mbti
        self.profile_pic = profile_pic
        
    def to_dict(self):
        """사용자 정보를 딕셔너리로 변환"""
        return {
            "username": self.username,
            "email": self.email,
            "password": self.password,
            "department": self.department,
            "interests": self.interests,
            "gender": self.gender,
            "age": self.age,
            "mbti": self.mbti,
            "profile_pic": self.profile_pic
        }
        
    @classmethod
    def from_dict(cls, data):
        """딕셔너리에서 사용자 객체 생성"""
        return cls(
            username=data.get("username", ""),
            email=data.get("email", ""),
            password=data.get("password", ""),
            department=data.get("department", ""),
            interests=data.get("interests", ""),
            gender=data.get("gender", ""),
            age=data.get("age", ""),
            mbti=data.get("mbti", ""),
            profile_pic=data.get("profile_pic", "")
        )