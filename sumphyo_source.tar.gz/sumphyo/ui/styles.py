# 색상 정의
PRIMARY_COLOR = (0.2, 0.7, 0.3, 1)    # 기본 강조 색상
SECONDARY_COLOR = (0.9, 0.9, 0.9, 1)  # 배경색
TEXT_COLOR = (0.1, 0.1, 0.1, 1)       # 텍스트 색상
ERROR_COLOR = (0.8, 0.2, 0.2, 1)      # 오류 색상

# 폰트 크기
FONT_LARGE = 24
FONT_MEDIUM = 18
FONT_SMALL = 14

# 레이아웃 설정
PADDING_STANDARD = 15
SPACING_STANDARD = 10