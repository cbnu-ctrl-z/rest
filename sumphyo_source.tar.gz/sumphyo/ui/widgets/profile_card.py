from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle
from ui.styles import *

class ProfileCard(BoxLayout):
    """사용자 프로필 정보를 표시하는 카드 위젯"""
    
    def __init__(self, user, matching_hours=None, **kwargs):
        super(ProfileCard, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint_y = None
        self.height = 150
        self.padding = 10
        
        # 카드 배경 설정
        with self.canvas.before:
            Color(*SECONDARY_COLOR)
            self.rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_rect, size=self._update_rect)
        
        # 사용자 정보
        info_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        
        # 사용자 이름
        info_box.add_widget(Label(
            text=user.username,
            font_size=FONT_MEDIUM,
            bold=True,
            size_hint_x=0.5
        ))
        
        # 학과
        info_box.add_widget(Label(
            text=f"학과: {user.department}",
            size_hint_x=0.5
        ))
        
        self.add_widget(info_box)
        
        # 매칭 시간 (있는 경우)
        if matching_hours is not None:
            self.add_widget(Label(
                text=f"공통 공강 시간: {matching_hours}시간",
                size_hint_y=None,
                height=30
            ))
        
        # 추가 정보 (나이, MBTI)
        info2_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=30)
        
        if user.age:
            info2_box.add_widget(Label(text=f"나이: {user.age}"))
        
        if user.mbti:
            info2_box.add_widget(Label(text=f"MBTI: {user.mbti}"))
            
        self.add_widget(info2_box)
        
        # 관심사
        self.add_widget(Label(
            text=f"관심사: {user.interests}",
            size_hint_y=None,
            height=40,
            text_size=(400, None),
            halign='left'
        ))
    
    def _update_rect(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size