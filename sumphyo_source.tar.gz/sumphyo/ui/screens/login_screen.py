from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from ui.styles import *

class LoginScreen(Screen):
    def __init__(self, auth_service, **kwargs):
        super(LoginScreen, self).__init__(**kwargs)
        self.auth_service = auth_service
        
        # UI 구성
        layout = BoxLayout(orientation='vertical', padding=PADDING_STANDARD, spacing=SPACING_STANDARD)
        
        # 제목
        title = Label(text="공강 매칭 앱", font_size=FONT_LARGE)
        subtitle = Label(text="함께할 친구를 찾아보세요!", font_size=FONT_SMALL)
        layout.add_widget(title)
        layout.add_widget(subtitle)
        
        # 빈 공간
        layout.add_widget(Label(size_hint_y=None, height=30))
        
        # 입력 필드
        username_label = Label(text="사용자 이름", halign='left', size_hint_y=None, height=20)
        username_label.bind(size=self._update_label_text_size)
        self.username_input = TextInput(hint_text="사용자 이름을 입력하세요", multiline=False, size_hint_y=None, height=40)
        
        password_label = Label(text="비밀번호", halign='left', size_hint_y=None, height=20)
        password_label.bind(size=self._update_label_text_size)
        self.password_input = TextInput(hint_text="비밀번호를 입력하세요", password=True, multiline=False, size_hint_y=None, height=40)
        
        layout.add_widget(username_label)
        layout.add_widget(self.username_input)
        layout.add_widget(password_label)
        layout.add_widget(self.password_input)
        
        # 빈 공간
        layout.add_widget(Label(size_hint_y=None, height=30))
        
        # 버튼
        login_btn = Button(text="로그인", background_color=PRIMARY_COLOR, size_hint_y=None, height=50)
        login_btn.bind(on_press=self.login)
        
        register_btn = Button(text="회원가입", size_hint_y=None, height=50)
        register_btn.bind(on_press=self.go_to_register)
        
        layout.add_widget(login_btn)
        layout.add_widget(register_btn)
        
        self.add_widget(layout)
    
    def _update_label_text_size(self, instance, value):
        instance.text_size = (value[0], None)
    
    def login(self, instance):
        username = self.username_input.text.strip()
        password = self.password_input.text
        
        if not username or not password:
            self.show_error("사용자 이름과 비밀번호를 입력하세요.")
            return
        
        if self.auth_service.login(username, password):
            self.manager.current = 'main'
        else:
            self.show_error("로그인 실패: 사용자 이름 또는 비밀번호가 올바르지 않습니다.")
    
    def go_to_register(self, instance):
        self.manager.current = 'register'
    
    def show_error(self, message):
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message))
        
        btn = Button(text="확인", size_hint=(1, None), height=40)
        content.add_widget(btn)
        
        popup = Popup(title='오류', content=content, size_hint=(0.8, 0.4))
        btn.bind(on_press=popup.dismiss)
        popup.open()