from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.clock import Clock
from ui.styles import *

class RegisterScreen(Screen):
    def __init__(self, auth_service, **kwargs):
        super(RegisterScreen, self).__init__(**kwargs)
        self.auth_service = auth_service
        
        layout = BoxLayout(orientation='vertical', padding=PADDING_STANDARD, spacing=SPACING_STANDARD)
        
        # 제목
        title_label = Label(
            text="회원가입",
            font_size=FONT_LARGE,
            size_hint=(1, None),
            height=50
        )
        layout.add_widget(title_label)
        
        # 스크롤 가능한 폼
        scroll_view = ScrollView(size_hint=(1, 1))
        form_layout = BoxLayout(orientation='vertical', size_hint=(1, None), padding=10, spacing=10)
        form_layout.bind(minimum_height=form_layout.setter('height'))
        
        # 사용자 이름
        username_label = Label(text="사용자 이름", size_hint=(1, None), height=30, halign='left')
        username_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(username_label)
        
        self.username_input = TextInput(
            multiline=False,
            size_hint=(1, None),
            height=40,
            hint_text="사용자 이름을 입력하세요"
        )
        form_layout.add_widget(self.username_input)
        
        # 이메일
        email_label = Label(text="이메일", size_hint=(1, None), height=30, halign='left')
        email_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(email_label)
        
        self.email_input = TextInput(
            multiline=False,
            size_hint=(1, None),
            height=40,
            hint_text="이메일 주소를 입력하세요"
        )
        form_layout.add_widget(self.email_input)
        
        # 비밀번호
        password_label = Label(text="비밀번호", size_hint=(1, None), height=30, halign='left')
        password_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(password_label)
        
        self.password_input = TextInput(
            multiline=False,
            password=True,
            size_hint=(1, None),
            height=40,
            hint_text="비밀번호를 입력하세요"
        )
        form_layout.add_widget(self.password_input)
        
        # 비밀번호 확인
        confirm_password_label = Label(text="비밀번호 확인", size_hint=(1, None), height=30, halign='left')
        confirm_password_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(confirm_password_label)
        
        self.confirm_password_input = TextInput(
            multiline=False,
            password=True,
            size_hint=(1, None),
            height=40,
            hint_text="비밀번호를 다시 입력하세요"
        )
        form_layout.add_widget(self.confirm_password_input)
        
        # 학과
        department_label = Label(text="학과", size_hint=(1, None), height=30, halign='left')
        department_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(department_label)
        
        self.department_input = TextInput(
            multiline=False,
            size_hint=(1, None),
            height=40,
            hint_text="학과를 입력하세요"
        )
        form_layout.add_widget(self.department_input)
        
        # 관심사
        interests_label = Label(text="관심사", size_hint=(1, None), height=30, halign='left')
        interests_label.bind(size=self._update_label_text_size)
        form_layout.add_widget(interests_label)
        
        self.interests_input = TextInput(
            multiline=True,
            size_hint=(1, None),
            height=80,
            hint_text="관심사를 입력하세요 (쉼표로 구분)"
        )
        form_layout.add_widget(self.interests_input)
        
        scroll_view.add_widget(form_layout)
        layout.add_widget(scroll_view)
        
        # 버튼 박스
        button_box = BoxLayout(orientation='horizontal', size_hint=(1, None), height=50, spacing=10)
        
        # 회원가입 버튼
        self.register_button = Button(
            text="회원가입",
            size_hint=(0.5, 1),
            background_color=PRIMARY_COLOR
        )
        self.register_button.bind(on_press=self.register)
        button_box.add_widget(self.register_button)
        
        # 취소 버튼
        self.cancel_button = Button(
            text="취소",
            size_hint=(0.5, 1),
            background_color=ERROR_COLOR
        )
        self.cancel_button.bind(on_press=self.cancel)
        button_box.add_widget(self.cancel_button)
        
        layout.add_widget(button_box)
        
        self.add_widget(layout)
    
    def _update_label_text_size(self, instance, value):
        instance.text_size = (value[0], None)
    
    def register(self, instance):
        username = self.username_input.text.strip()
        email = self.email_input.text.strip()
        password = self.password_input.text
        confirm_password = self.confirm_password_input.text
        department = self.department_input.text.strip()
        interests = self.interests_input.text.strip()
        
        # 기본 유효성 검사
        if not username:
            self.show_error("사용자 이름을 입력하세요.")
            return
        
        if not email or '@' not in email or '.' not in email:
            self.show_error("유효한 이메일 주소를 입력하세요.")
            return
        
        if not password:
            self.show_error("비밀번호를 입력하세요.")
            return
        
        if password != confirm_password:
            self.show_error("비밀번호가 일치하지 않습니다.")
            return
        
        if len(password) < 6:
            self.show_error("비밀번호는 최소 6자 이상이어야 합니다.")
            return
        
        # 회원가입 시도
        if self.auth_service.register(username, email, password, department=department, interests=interests):
            self.show_success("회원가입이 완료되었습니다!")
            Clock.schedule_once(lambda dt: self.go_to_login(), 1.5)
        else:
            self.show_error("해당 사용자 이름 또는 이메일이 이미 존재합니다.")
    
    def cancel(self, instance):
        self.manager.current = 'login'
        self.clear_inputs()
    
    def go_to_login(self):
        self.manager.current = 'login'
        self.clear_inputs()
    
    def clear_inputs(self):
        self.username_input.text = ""
        self.email_input.text = ""
        self.password_input.text = ""
        self.confirm_password_input.text = ""
        self.department_input.text = ""
        self.interests_input.text = ""
    
    def show_error(self, message):
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message))
        
        btn = Button(text="확인", size_hint=(1, None), height=40)
        content.add_widget(btn)
        
        popup = Popup(title='오류', content=content, size_hint=(0.8, 0.4))
        btn.bind(on_press=popup.dismiss)
        popup.open()
    
    def show_success(self, message):
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message))
        
        popup = Popup(title='성공', content=content, size_hint=(0.8, 0.4), auto_dismiss=True)
        popup.open()
        
        # 1.5초 후 자동으로 닫기
        Clock.schedule_once(popup.dismiss, 1.5)