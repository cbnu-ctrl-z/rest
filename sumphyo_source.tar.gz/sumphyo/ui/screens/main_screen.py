from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.popup import Popup
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle
from ui.styles import *
import config

class MainScreen(Screen):
    def __init__(self, auth_service, data_service, matching_service, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        self.auth_service = auth_service
        self.data_service = data_service
        self.matching_service = matching_service
        
        layout = BoxLayout(orientation='vertical')
        
        # 상단 제목 바
        header = BoxLayout(orientation='horizontal', size_hint=(1, None), height=50, padding=[10, 5])
        header.add_widget(Label(text="공강 매칭 앱", font_size=18))
        
        # 로그아웃 버튼
        logout_btn = Button(text="로그아웃", size_hint=(0.3, 0.8), pos_hint={'center_y': 0.5})
        logout_btn.bind(on_press=self.logout)
        header.add_widget(logout_btn)
        
        layout.add_widget(header)
        
        # 탭 버튼들
        tabs = BoxLayout(orientation='horizontal', size_hint=(1, None), height=50)
        
        self.profile_btn = Button(text="프로필")
        self.profile_btn.bind(on_press=self.show_profile)
        tabs.add_widget(self.profile_btn)
        
        self.schedule_btn = Button(text="시간표")
        self.schedule_btn.bind(on_press=self.show_schedule)
        tabs.add_widget(self.schedule_btn)
        
        self.matching_btn = Button(text="매칭")
        self.matching_btn.bind(on_press=self.show_matching)
        tabs.add_widget(self.matching_btn)
        
        layout.add_widget(tabs)
        
        # 콘텐츠 영역
        self.content_area = BoxLayout(orientation='vertical', padding=10)
        layout.add_widget(self.content_area)
        
        self.add_widget(layout)
        
        # 0.5초 후에 프로필 탭 활성화
        Clock.schedule_once(self.activate_profile_tab, 0.5)
    
    def activate_profile_tab(self, dt):
        self.show_profile(None)
    
    def logout(self, instance):
        self.auth_service.logout()
        self.manager.current = 'login'
    
    def clear_content(self):
        self.content_area.clear_widgets()
    
    def show_profile(self, instance):
        # 버튼 강조
        self.profile_btn.background_color = PRIMARY_COLOR
        self.schedule_btn.background_color = (1, 1, 1, 1)
        self.matching_btn.background_color = (1, 1, 1, 1)
        
        self.clear_content()
        
        # 프로필 화면 생성
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        # 스크롤 가능한 레이아웃
        scroll_view = ScrollView()
        profile_layout = BoxLayout(orientation='vertical', padding=15, spacing=15, size_hint_y=None)
        profile_layout.bind(minimum_height=profile_layout.setter('height'))
        
        # 프로필 제목
        profile_layout.add_widget(Label(
            text=f"{user.username}님의 프로필",
            font_size=20,
            size_hint_y=None,
            height=40,
            bold=True
        ))
        
        # 프로필 사진 영역
        photo_box = BoxLayout(orientation='vertical', size_hint_y=None, height=180)
        
        # 기본 프로필 이미지 또는 사용자 프로필 이미지
        self.profile_image = Image(
            source=user.profile_pic or config.DEFAULT_PROFILE_IMAGE,
            size_hint=(None, None),
            size=(150, 150),
            pos_hint={'center_x': 0.5}
        )
        photo_box.add_widget(self.profile_image)
        
        # 사진 변경 버튼
        photo_btn = Button(
            text="프로필 사진 변경",
            size_hint=(None, None),
            size=(150, 30),
            pos_hint={'center_x': 0.5}
        )
        photo_btn.bind(on_press=self.change_profile_pic)
        photo_box.add_widget(photo_btn)
        
        profile_layout.add_widget(photo_box)
        
        # 프로필 정보 폼
        form = GridLayout(cols=2, spacing=10, size_hint_y=None)
        form.bind(minimum_height=form.setter('height'))
        
        # 이메일 (변경 불가)
        form.add_widget(Label(text="이메일:", size_hint_y=None, height=40, halign='right'))
        form.add_widget(Label(text=user.email, size_hint_y=None, height=40, halign='left'))
        
        # 학과
        form.add_widget(Label(text="학과:", size_hint_y=None, height=40))
        self.department_input = TextInput(
            text=user.department,
            multiline=False,
            hint_text="학과를 입력하세요",
            size_hint_y=None, 
            height=40
        )
        form.add_widget(self.department_input)
        
        # 나이
        form.add_widget(Label(text="나이:", size_hint_y=None, height=40))
        self.age_input = TextInput(
            text=user.age,
            multiline=False,
            hint_text="나이를 입력하세요",
            size_hint_y=None, 
            height=40
        )
        form.add_widget(self.age_input)
        
        # 성별
        form.add_widget(Label(text="성별:", size_hint_y=None, height=40))
        gender_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        
        self.male_btn = Button(text="남성", background_color=(0.7, 0.7, 0.7, 1))
        self.female_btn = Button(text="여성", background_color=(0.7, 0.7, 0.7, 1))
        
        if user.gender == '남성':
            self.male_btn.background_color = PRIMARY_COLOR
        elif user.gender == '여성':
            self.female_btn.background_color = PRIMARY_COLOR
            
        self.male_btn.bind(on_press=lambda x: self.select_gender('남성'))
        self.female_btn.bind(on_press=lambda x: self.select_gender('여성'))
        
        gender_box.add_widget(self.male_btn)
        gender_box.add_widget(self.female_btn)
        form.add_widget(gender_box)
        
        # MBTI
        form.add_widget(Label(text="MBTI:", size_hint_y=None, height=40))
        self.mbti_input = TextInput(
            text=user.mbti,
            multiline=False,
            hint_text="MBTI를 입력하세요 (예: ENFP)",
            size_hint_y=None, 
            height=40
        )
        form.add_widget(self.mbti_input)
        
        # 관심사
        form.add_widget(Label(text="관심사:", size_hint_y=None, height=80))
        self.interests_input = TextInput(
            text=user.interests,
            multiline=True,
            hint_text="관심사를 입력하세요 (쉼표로 구분)",
            size_hint_y=None, 
            height=80
        )
        form.add_widget(self.interests_input)
        
        profile_layout.add_widget(form)
        
        # 저장 버튼
        save_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, padding=[0, 20, 0, 0])
        
        save_btn = Button(
            text="프로필 저장",
            size_hint=(1, None),
            height=50,
            background_color=PRIMARY_COLOR
        )
        save_btn.bind(on_press=self.save_profile)
        save_box.add_widget(save_btn)
        
        profile_layout.add_widget(save_box)
        
        # 프로필 레이아웃의 총 높이 계산
        profile_layout.height = sum(widget.height for widget in profile_layout.children) + (len(profile_layout.children) - 1) * profile_layout.spacing
        
        scroll_view.add_widget(profile_layout)
        self.content_area.add_widget(scroll_view)
    
    def select_gender(self, gender):
        if gender == '남성':
            self.male_btn.background_color = PRIMARY_COLOR
            self.female_btn.background_color = (0.7, 0.7, 0.7, 1)
        else:
            self.male_btn.background_color = (0.7, 0.7, 0.7, 1)
            self.female_btn.background_color = PRIMARY_COLOR
        self.selected_gender = gender

    def change_profile_pic(self, instance):
        # 파일 선택 기능 구현 (실제 구현은 복잡하므로 메시지만 표시)
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text="프로필 사진 변경 기능은 추후 업데이트될 예정입니다."))
        
        btn = Button(text="확인", size_hint=(1, None), height=40)
        content.add_widget(btn)
        
        popup = Popup(title='안내', content=content, size_hint=(0.8, 0.4))
        btn.bind(on_press=popup.dismiss)
        popup.open()

    def save_profile(self, instance):
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        # 입력 값 가져오기
        department = self.department_input.text.strip()
        interests = self.interests_input.text.strip()
        age = self.age_input.text.strip()
        mbti = self.mbti_input.text.strip()
        gender = getattr(self, 'selected_gender', user.gender)
        
        # 프로필 업데이트
        if self.auth_service.update_profile(
            department=department,
            interests=interests,
            gender=gender,
            age=age,
            mbti=mbti
        ):
            self.show_message("프로필이 저장되었습니다.")
        else:
            self.show_message("프로필 저장 중 오류가 발생했습니다.", 'error')
    
    def show_schedule(self, instance):
        # 버튼 강조
        self.profile_btn.background_color = (1, 1, 1, 1)
        self.schedule_btn.background_color = PRIMARY_COLOR
        self.matching_btn.background_color = (1, 1, 1, 1)
        
        self.clear_content()
        
        # 시간표 화면 생성
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        # 기존 스케줄 불러오기
        schedule = self.data_service.get_schedule(user.username)
        if not schedule:
            from models.schedule import Schedule
            schedule = Schedule(user.username)
        
        schedule_layout = BoxLayout(orientation='vertical', padding=10)
        
        # 시간표 제목
        schedule_layout.add_widget(Label(
            text="공강 시간표",
            font_size=20,
            size_hint=(1, None),
            height=40
        ))
        
        # 스크롤 가능한 시간표
        scroll_view = ScrollView()
        grid = GridLayout(cols=6, spacing=2, size_hint_y=None)
        grid.bind(minimum_height=grid.setter('height'))
        
        # 헤더 행
        grid.add_widget(Label(text="시간", size_hint_y=None, height=40))
        for day in config.DAYS:
            grid.add_widget(Label(text=day, size_hint_y=None, height=40))
        
        # 시간 슬롯별 행
        self.schedule_checkboxes = {}
        
        for time_slot in config.TIME_SLOTS:
            grid.add_widget(Label(text=time_slot, size_hint_y=None, height=40))
            
            for day in config.DAYS:
                # 체크박스 초기값 설정
                initial_value = schedule.is_free_time(day, time_slot)
                
                # 레이아웃에 체크박스 추가
                box = BoxLayout(orientation='vertical', size_hint_y=None, height=40)
                cb = CheckBox(active=initial_value)
                box.add_widget(cb)
                grid.add_widget(box)
                
                # 체크박스 저장
                if day not in self.schedule_checkboxes:
                    self.schedule_checkboxes[day] = {}
                self.schedule_checkboxes[day][time_slot] = cb
        
        scroll_view.add_widget(grid)
        schedule_layout.add_widget(scroll_view)
        
        # 저장 버튼
        save_btn = Button(
            text="시간표 저장",
            size_hint=(1, None),
            height=50,
            background_color=PRIMARY_COLOR
        )
        save_btn.bind(on_press=self.save_schedule)
        schedule_layout.add_widget(save_btn)
        
        self.content_area.add_widget(schedule_layout)
    
    def save_schedule(self, instance):
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        # 체크박스 값을 스케줄 데이터로 변환
        from models.schedule import Schedule
        schedule = Schedule(user.username)
        
        for day in self.schedule_checkboxes:
            for time_slot in self.schedule_checkboxes[day]:
                # True = 공강, False = 수업
                is_free = self.schedule_checkboxes[day][time_slot].active
                schedule.set_free_time(day, time_slot, is_free)
        
        # 스케줄 저장
        if self.data_service.save_schedule(schedule):
            self.show_message("시간표가 저장되었습니다.")
        else:
            self.show_message("시간표 저장 중 오류가 발생했습니다.", 'error')
    
    def show_matching(self, instance):
        # 버튼 강조
        self.profile_btn.background_color = (1, 1, 1, 1)
        self.schedule_btn.background_color = (1, 1, 1, 1)
        self.matching_btn.background_color = PRIMARY_COLOR
        
        self.clear_content()
        
        # 매칭 화면 생성
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        matching_layout = BoxLayout(orientation='vertical', padding=10)
        
        # 매칭 제목
        matching_layout.add_widget(Label(
            text="공강 시간이 맞는 친구들",
            font_size=20,
            size_hint=(1, None),
            height=40
        ))
        
        # 매칭 버튼
        find_btn = Button(
            text="매칭 찾기",
            size_hint=(1, None),
            height=50,
            background_color=PRIMARY_COLOR
        )
        find_btn.bind(on_press=self.find_matches)
        matching_layout.add_widget(find_btn)
        
        # 결과 표시 영역
        self.results_area = BoxLayout(orientation='vertical', padding=10)
        matching_layout.add_widget(self.results_area)
        
        self.content_area.add_widget(matching_layout)
    
    def find_matches(self, instance):
        user = self.auth_service.get_current_user()
        if not user:
            return
        
        self.results_area.clear_widgets()
        
        # 스케줄이 있는지 확인
        schedule = self.data_service.get_schedule(user.username)
        if not schedule:
            self.results_area.add_widget(Label(
                text="시간표를 먼저 등록해주세요!",
                font_size=16
            ))
            return
        
        # 매칭 검색
        matches = self.matching_service.find_matches(user.username)
        
        if not matches:
            self.results_area.add_widget(Label(
                text="매칭된 사용자가 없습니다.",
                font_size=16
            ))
            return
        
        # 매칭 결과 스크롤 목록
        scroll_view = ScrollView()
        results_grid = GridLayout(cols=1, spacing=10, size_hint_y=None)
        results_grid.bind(minimum_height=results_grid.setter('height'))
        
        for match in matches:
            # 매칭된 사용자 카드
            card = BoxLayout(orientation='vertical', size_hint_y=None, height=150, padding=10)
            with card.canvas.before:
                Color(0.9, 0.9, 0.9, 1)
                rect = Rectangle(pos=card.pos, size=card.size)
                # 위치와 크기 업데이트를 위한 바인딩
                card.bind(pos=lambda obj, pos: setattr(rect, 'pos', pos))
                card.bind(size=lambda obj, size: setattr(rect, 'size', size))
            
            # 사용자 정보
            info_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
            
            matched_user = match['user']
            
            # 사용자 이름
            info_box.add_widget(Label(
                text=matched_user.username,
                font_size=18,
                bold=True,
                size_hint_x=0.5
            ))
            
            # 학과
            info_box.add_widget(Label(
                text=f"학과: {matched_user.department}",
                size_hint_x=0.5
            ))
            
            card.add_widget(info_box)
            
            # 매칭 시간
            card.add_widget(Label(
                text=f"공통 공강 시간: {match['matching_hours']}시간",
                size_hint_y=None,
                height=30
            ))
            
            # 추가 정보 (나이, MBTI)
            info2_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=30)
            
            if matched_user.age:
                info2_box.add_widget(Label(text=f"나이: {matched_user.age}"))
            
            if matched_user.mbti:
                info2_box.add_widget(Label(text=f"MBTI: {matched_user.mbti}"))
                
            card.add_widget(info2_box)
            
            # 관심사
            card.add_widget(Label(
                text=f"관심사: {matched_user.interests}",
                size_hint_y=None,
                height=40,
                text_size=(400, None),
                halign='left'
            ))
            
            results_grid.add_widget(card)
        
            scroll_view.add_widget(results_grid)
            self.results_area.add_widget(scroll_view)
    def show_message(self, message, message_type='info'):
        title = '알림' if message_type == 'info' else '오류'
        
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(text=message))
        
        btn = Button(text="확인", size_hint=(1, None), height=40)
        content.add_widget(btn)
        
        popup = Popup(title=title, content=content, size_hint=(0.8, 0.4))
        btn.bind(on_press=popup.dismiss)
        popup.open()